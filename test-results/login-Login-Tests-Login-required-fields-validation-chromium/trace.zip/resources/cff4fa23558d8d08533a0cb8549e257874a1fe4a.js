(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_dist_3d8feecb._.js",
  "static/chunks/[root-of-the-server]__0f0ba101._.css"
],
    source: "dynamic"
});
